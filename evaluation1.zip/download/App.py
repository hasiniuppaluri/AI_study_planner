import streamlit as st
import cohere
import datetime
import time  
import plotly.express as px
try:
    cohere_api_key = st.secrets["cohere"]["api_key"]
except KeyError as e:
    st.error(f"Missing secret: {e}. Please configure your Streamlit secrets.")
    st.stop()
cohere_client = cohere.Client(cohere_api_key)
def generate_study_plan(course_load, deadlines, preferences):
    today = datetime.date.today()
    deadline_dates = [d['date'] for d in deadlines if 'date' in d]
    last_deadline = max(deadline_dates) if deadline_dates else today
    total_days = (last_deadline - today).days

    if total_days < 1:
        st.error("All deadlines should be in the future.")
        return None

    prompt = f"""
    Generate a structured daily study plan from {today} to {last_deadline} 
    for the following courses: {course_load}.
    Consider the following preferences: {preferences}.
    Ensure the schedule is well-balanced and realistic.
    """

    try:
        response = cohere_client.generate(
            model='command',
            prompt=prompt,
            max_tokens=500
        )
        return response.generations[0].text.strip()
    except Exception as e:
        st.error(f"Error generating study plan: {e}")
        return None

# Function to display progress as a pie chart
def circular_progress(progress):
    completed_percent = progress
    remaining_percent = 100 - progress

    data = {'Status': ['Completed', 'Remaining'], 'Count': [completed_percent, remaining_percent]}
    color_sequence = ['#1E90FF', '#D3D3D3'] if progress > 0 else ['#D3D3D3', '#D3D3D3']
    
    fig = px.pie(data, values='Count', names='Status',
                 color_discrete_sequence=color_sequence,
                 hole=0.7)

    fig.update_traces(textinfo='none', showlegend=False)
    fig.update_layout(
        height=150, width=150,
        margin=dict(l=0, r=0, t=0, b=0),
        paper_bgcolor="rgba(0,0,0,0)"
    )
    st.plotly_chart(fig, use_container_width=False)

# UI Layout
st.set_page_config(page_title="StudBud - AI Study Planner", page_icon="📚", layout="wide")

st.sidebar.title("📚 StudBud AI Planner")
st.sidebar.write("Plan your study sessions with AI assistance!")

# Sidebar Inputs
st.sidebar.header("🗓 Add Courses & Deadlines")
if 'deadlines' not in st.session_state:
    st.session_state.deadlines = []

if st.sidebar.button('➕ Add Course'):
    st.session_state.deadlines.append({'course': '', 'date': datetime.date.today()})

for idx, deadline in enumerate(st.session_state.deadlines):
    with st.sidebar.expander(f'📖 Course {idx+1}'):
        st.session_state.deadlines[idx]['course'] = st.text_input(f'Course {idx+1}', key=f'course_{idx}', value=deadline['course'])
        st.session_state.deadlines[idx]['date'] = st.date_input(f'Deadline {idx+1}', key=f'date_{idx}', value=deadline['date'])

preferences = st.sidebar.text_area('📝 Study Preferences', placeholder='e.g., morning study sessions')

st.title('📚 StudBud: AI Study Planner')
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("✅ To-Do List")
    if "todo_list" not in st.session_state:
        st.session_state.todo_list = []

    new_task = st.text_input("Add a new task", key="new_task")
    if st.button("➕ Add Task") and new_task:
        st.session_state.todo_list.append({'task': new_task, 'done': False})
        st.rerun()

    tasks_to_remove = []
    for idx, task in enumerate(st.session_state.todo_list):
        col_task, col_delete = st.columns([0.9, 0.1])
        with col_task:
            checked = st.checkbox(task["task"], value=task["done"], key=f"task_{idx}")
            st.session_state.todo_list[idx]["done"] = checked
        with col_delete:
            if st.button("❌", key=f"delete_{idx}"):
                tasks_to_remove.append(idx)

    for idx in sorted(tasks_to_remove, reverse=True):
        del st.session_state.todo_list[idx]

    completed_tasks = sum(1 for task in st.session_state.todo_list if task["done"])
    total_tasks = len(st.session_state.todo_list)
    progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0

    st.subheader("📊 Progress Tracking")
    circular_progress(progress)
    st.write(f"Completion: {progress:.2f}%")

    # Generate Study Plan Section
    if st.button("📋 Generate Study Plan"):
        study_plan = generate_study_plan(
            course_load=[d['course'] for d in st.session_state.deadlines],
            deadlines=st.session_state.deadlines,
            preferences=preferences
        )
        if study_plan:
            st.text_area("Your Study Plan:", study_plan, height=300)

with col2:
    st.subheader('🍅 Pomodoro Timer')
    work_time = st.slider('Work Duration (minutes)', 5, 60, 25)
    break_time = st.slider('Break Duration (minutes)', 2, 30, 5)

    if st.button('Start Pomodoro'):
        st.success("Pomodoro session started! Stay focused. ⏳")
        timer_placeholder = st.empty()

        for phase, duration in [("Work", work_time), ("Break", break_time)]:
            for i in range(duration * 60, 0, -1):
                if i % 5 == 0:
                    mins, secs = divmod(i, 60)
                    timer_placeholder.write(f"⏳ {phase} Time Remaining: {mins:02d}:{secs:02d}")
                    time.sleep(5)

            st.success(f"{phase} session is over! 🎉")
